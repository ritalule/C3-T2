#Required
library(readr)
library(plyr)
library(ggplot2)
library(caret)
library(survival)
library(splines)
library(parallel)
library(C50)
library(gbm)
library(randomForest)


## Import Data
CompleteResponses<- read.csv("~/Project 2/Project 2/CompleteResponses.csv")
View(CompleteResponses)

## Inspect Data
str(CompleteResponses)
summary(CompleteResponses)

## Change Brand to a factor
CompleteResponses$brand<- as.factor(CompleteResponses$brand)
str(CompleteResponses)

#caret model - Random Forest
## define an 75%/25% train/test split of the dataset
set.seed(998)
inTraining<- createDataPartition(CompleteResponses$brand, p=.75, list=FALSE)
training<- CompleteResponses[inTraining,]
testing<- CompleteResponses[-inTraining,]

## 10 fold cross validation
fitControl<- trainControl(method = "repeatedcv", number = 10, repeats = 1)

#train Random Forest Regression model with a tuneLenght = 1 (trains with 1 mtry value for RandomForest)
rf_brand<- train(brand~., data = training, method = "rf", trControl=fitControl, tuneLength = 3)

#training results
rf_brand

# Variable Importance Random Forest
varImp(rf_brand)

#caret model - GBM
gbm_brand<- train(brand~.,data = training, method = "gbm", trControl= fitControl, verbose = FALSE)
gbm_brand

# Variable Importance GBM
varImp(gbm_brand)

save.image()

pred_rf <- predict(rf_brand, testing)
pred_rf


pred_gbm <- predict(gbm_brand, testing)
pred_gbm

resample_results<- resamples(list(RandomForest = rf_brand, gbm = gbm_brand ))
resample_results

resample_results$values
summary(resample_results)
bwplot(resample_results)
diff_results<- diff(resample_results)
summary(diff_results, metric = "accuracy")
compare_models(rf_brand, gbm_brand)

## Predict with RandomForest
testPredrf1 <- predict(rf_brand, testing)
postResample(testPredrf1, testing$brand)
confusionMatrix(testPredrf1, testing$brand)

save.image()


## Final Prediction on Survey Incomplete
finalPredrf1 <- predict(rf_brand, CompleteResponses)

## Get Predicted Preference Totals
summary(finalPredrf1)

## Get Known Preference Totals
summary(CompleteResponses$brand)

## The problem of ground truth and unseen data with no y
postResample(finalPredrf1,CompleteResponses$brand)